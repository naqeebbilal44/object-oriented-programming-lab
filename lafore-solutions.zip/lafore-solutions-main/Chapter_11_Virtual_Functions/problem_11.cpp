#include <iostream>

int main()
{
    // Q8 from the same unit
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
